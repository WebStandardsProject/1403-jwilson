The language pack template files:

* package.json
* context.json
* view.json

[How to create a language pack?](https://github.com/oklai/koala/wiki/How-to-create-a-language-pack%3F)