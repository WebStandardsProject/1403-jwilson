# Require any additional compass plugins here.
project_type = :stand_alone
css_dir = "stylesheets"
sass_dir = "src"
images_dir = "images"
output_style = :compact
relative_assets = true
line_comments = false
