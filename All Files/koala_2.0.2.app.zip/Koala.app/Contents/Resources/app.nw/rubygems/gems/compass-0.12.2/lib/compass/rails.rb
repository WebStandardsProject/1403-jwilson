# Rails requires compass by requiring this file.
require 'compass'
