Compass::Frameworks.register("only-stylesheets", :stylesheets_dir => File.join(File.dirname(__FILE__),"scss"))
